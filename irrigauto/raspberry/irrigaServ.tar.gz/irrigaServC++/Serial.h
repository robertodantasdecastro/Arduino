

int setaAtributos (int porta, int velocidade, int par){

    struct termios tty;
    memset(&tty, 0, sizeof tty);
    if (tcgetattr(porta, &tty) != 0) {
        printf ("erro 1 de atributos tccgetattr n: %d", errno);
        return (-1);
    }
    bzero(&tty, sizeof(tty));
    cfsetospeed(&tty, velocidade);
    cfsetispeed(&tty, velocidade);

    tty.c_cflag = (tty.c_cflag & ~CSIZE)|CS8;
    tty.c_cflag &= ~PARENB;
    tty.c_cflag &= ~CSTOPB;
    tty.c_iflag &= ~IGNBRK;
 //   tty.c_cflag &= ~IGNPAR;
    tty.c_lflag = ICANON;
    tty.c_oflag = 0;
    tty.c_cc[VMIN]  = 0;
    tty.c_cc[VTIME] = 20;
    tty.c_iflag &= ~(IXON | IXOFF | IXANY);
    tty.c_cflag |= (CLOCAL | CREAD);
    tty.c_cflag &= ~CRTSCTS;
    if (tcsetattr (porta, TCSANOW, &tty) != 0) {
        printf ("erro 2 de atributos tccgetattr n: %d", errno);
        return (-1);
    }
    return (0);
 }
 int conectaSerial (){

    char *devporta = (PORTA);
	int conecta = open(devporta, O_RDWR);
    if (conecta == -1){
        printf ("erro abrindo encontrado: ", errno);
        return(-1);
    } else {
        setaAtributos(conecta,VELOCIDADE,0);
        return(conecta);
    }
}

char *lerSerial(){
    int conecta = conectaSerial ();
    bool aguarda = true;
    char recebe[255];
    int n = 0;
    while (aguarda) {

        int res=read (conecta, recebe, sizeof recebe);


        if (res<0){
            aguarda=false;
            return("-1");
        }else {

            if (recebe[0]=='@'){
                recebe[res-2]='\0';
                usleep(10000);
                aguarda=false;
                close(conecta);
                return (recebe);
            }
        }
    }
    close(conecta);
}
int enviarSerial(char* valor){
    int conecta = conectaSerial ();
    int tamanho = strlength(valor);

    int ok=write(conecta, valor, tamanho);
    usleep(1000*1000);
    printf("\nenviando String: %s:%i\n",valor, tamanho);

    if(ok!=tamanho){
        printf("erro");
        close(conecta);
        return -1;
    } else {

    return ok;
    }
    close(conecta);
}
