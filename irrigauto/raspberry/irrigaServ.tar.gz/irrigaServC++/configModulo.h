int configModulo()
{
    char qry[1024];
    sprintf (qry,"SELECT id,porta,tipo FROM bombas WHERE ativo='1' AND id_modulo='%i';",ID_MODULO);
    if(mysql_query(MySQL_con, qry))
    {
        if (bd_sai_erro(MySQL_con) ==-1)
            return -1;
    }
    else
    {
        MYSQL_RES *resBomba=mysql_store_result(MySQL_con);

        if (resBomba==NULL)
        {
            if (bd_sai_erro(MySQL_con) ==-1)
                return -1;
        }
        int bombaTotal=mysql_num_rows(resBomba);
        int bombaNum=mysql_num_fields(resBomba);

        MYSQL_ROW linha;

        MYSQL_ROW linhaValvula;
        //  MYSQL_FIELD *titulo;
        int bomba[bombaNum];
        char strBomba[255];
        sprintf(strBomba, "@B%i;",bombaTotal);
        //int envia=enviarSerial(strBomba);

        int envia = 0;
        bool enviarBmb =true;
        int valBMB;
        while (enviarBmb)
        {
            printf("\n--loop bmb--\n");
            envia=enviarSerial(strBomba);
            if (envia>0)
            {
                char *respCFG=lerSerial();
                valBMB = validaCMD(respCFG,"OKBMB");
                usleep(100000);
                if (valBMB==1)
                {
                    enviarBmb=false;
                }
                else
                {
                    printf("renviando String BOMBA");
                }
            }
        }


        /*int valBMB;
        if (envia>0)
        {
 //            usleep(10000*10);
            char *respCFG=lerSerial();
//            printf ("RESPOSTA: \'%s\'\n", respCFG);

            valBMB = validaCMD(respCFG,"OKBMB");
        }*/
        //valBMB=1;

        if (valBMB>0)
        {

            while (linha = mysql_fetch_row(resBomba))
            {
                for(int i=0; i<bombaNum; i++)
                {
                    if (i==0)
                    {
                        /*  while (titulo=mysql_fetch_field(resBomba))
                          {
                              printf("%s ",titulo->name);
                          }*/
                        int id_bomba = atoi(linha[0]);
                        int porta_bomba = atoi(linha[1]);

                        char *tipo_porta_bomba = linha[3];
                        int portaEstado_bomba;
                        char *tipo_portaEstado_bomba;

                        if (linha[2]!=NULL)
                        {
                            portaEstado_bomba = atoi(linha[2]);
                            tipo_portaEstado_bomba=linha[4];
                        }
                        bomba[id_bomba]=porta_bomba;
//                        printf("id->%i porta->%i\n",id_bomba,bomba[id_bomba]);
                        char qryval[1024];
                        sprintf(qryval, "SELECT id,porta,porta_tipo FROM valvulas WHERE ativo='1' AND id_bomba='%i';",id_bomba);
                        mysql_query(MySQL_con,qryval);
                        //  printf("QRY: %s\nSaindo: %i\n",qryval);
                        MYSQL_RES *resVal=mysql_store_result(MySQL_con);
                        if (resVal==NULL)
                        {
                            if (bd_sai_erro(MySQL_con) ==-1)
                                return -1;
                        }
                        int valvNum=mysql_num_fields(resVal);
                        int valvTotal=mysql_num_rows(resVal);
                        // int valv[bombaNum][valvNum];

                        char strTemp[255];
                        sprintf(strTemp,"@V|B:");

                        char B[3];
                        //char VB[3];
                        if (porta_bomba<10)
                        {
                            sprintf(B,"%s0%i,",tipo_porta_bomba,porta_bomba);
                        } else {
                            sprintf(B,"%s%i,",tipo_porta_bomba,porta_bomba);
                        }

                        strcat(strTemp,B);
                        if (portaEstado_bomba==NULL)
                        {
                            strcat(strTemp,"XXX{");
                        }
                        else
                        {

                            char VB[3];
                            if (portaEstado_bomba<10)
                            {
                                sprintf(VB,"%s0%i{",tipo_portaEstado_bomba,portaEstado_bomba);
                            } else {
                                sprintf(VB,"%s%i{",tipo_portaEstado_bomba,portaEstado_bomba);
                            }
                            strcat(strTemp,VB);

                        }

                        // sprintf(strTemp,"@V{");
                        int contaLinha=0;
                        while (linhaValvula=mysql_fetch_row(resVal))
                        {
                            for (int a=0; a<valvNum; a++)
                            {
                                if(a==0)
                                {
                                    int id_valv=atoi(linhaValvula[0]);
                                    int porta_valv=atoi(linhaValvula[1]);
                                    char n[3];
                                    if (contaLinha < valvTotal-1)
                                    {
                                        if (porta_valv < 10){
                                            sprintf (n, "0%i,", porta_valv);
                                        } else {
                                            sprintf (n, "%i,", porta_valv);
                                        }
                                    }
                                    else
                                    {
                                        if (porta_valv <10) {

                                            sprintf (n, "0%i", porta_valv);
                                        }else {
                                            sprintf (n, "%i", porta_valv);
                                        }
                                    }
                                    strcat(strTemp,n);
                                    contaLinha++;

                                    //   printf("\n-->%i<--\n",contaLinha);
                                }
                            }
                        }
                        char strFim[15];

                        sprintf(strFim,"};",porta_bomba);
                        strcat(strTemp,strFim);
                        //                      printf("-->%s",strTemp);
                        bool enviarLinha = true;

                        while(enviarLinha)
                        {
                            //usleep(1000000);
                            printf("loop envia linha");
                            int enviaConfig=enviarSerial(("%s",strTemp));

                            if (enviaConfig>0)
                            {
                                char *respConfig=lerSerial();
                                usleep(100000);
                                if (validaCMD(respConfig,"OKVAL") >0 or validaCMD(respConfig,"CONFIG") >0)
                                {
                                    enviarLinha=false;
                                } else
                                if (validaCMD(respConfig,"ERR") >0)
                                {
                                    printf("Erro - reenviando a linha!");
                                }
                            } else {
                                printf("erro de envio!");
                            }
                        }

/*
                        int enviaConfig=enviarSerial(("%s",strTemp));

                        if (enviaConfig>0)
                        {
                            char *respConfig=lerSerial();
                            //                        printf ("RESPOSTA: \'%s\'\n", respConfig);
                            int valBMB = validaCMD(respConfig,"OKVAL");
                            //     printf("%i",valBMB);

                        }
*/
                        mysql_free_result(resVal);
//                       printf("...\n");
                        //usleep(10000*10);
                    }
                    // printf("%s ",linha[0]);
                }
//               printf("FIM\n");
            }
        }
        else {
            return -1;
        }
        mysql_free_result(resBomba);

//       printf("\nSAIU MYSQL\n");
    }

    char *strenv = "@F;";
    int envia=enviarSerial(strenv);
    if (envia>0)
    {
        char *respCFG=lerSerial();
//        printf ("RESPOSTA: \'%s\'\n", respCFG);


        if (validaCMD(respCFG,"OKCFG")>0)
        {

            return 1;
        }
    }
}
