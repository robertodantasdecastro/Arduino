
#define VELOCIDADE B57600
#define PORTA "/dev/ttyAMA0"
#define host "localhost"
#define user "irrig"
#define pass "access"
#define db "irrigauto"
#define CHAVE_CMD '@'
#define TIMEOUT_AGUARDA 100
#define ID_MODULO 1
#define RESET_ARDUINO 18

MYSQL *MySQL_con=NULL;



