
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <error.h>
#include <errno.h>
#include <termios.h>
#include <string.h>
#include <wiringPi.h>



#include <mysql/my_sys.h>
#include <mysql/my_global.h>
#include <mysql/mysql.h>

#include "config.h"
#include "funcoes.h"
#include "Serial.h"
#include "banco.h"
#include "configModulo.h"

int main(int argc, char **argv)
{

    printf ("--> iniciando...\n");
    wiringPiSetupSys();
    //resetaModulo();
    if (conectarBanco())//conecta banco de dados
    {
        bool aguarda = true;
        long n =0;
        if (configModulo()>-1)
        {
            printf("Modulo ok");

            while (aguarda)  //loop principal - aguardando serial
            {
                char *receba = lerSerial();
                usleep(1000);
                if (receba[0]=='@') //valida caractere inicial
                {
                    // --- Iniciando nivel de reconhecimento de comandos

                    int valConfig = validaCMD(receba,"CONFIG");
printf ("\n---- %i ----\n", valConfig);
                    if (valConfig>0)
                    {
                        char *cmd= pegaCmd(receba);
                        printf("=======\'%s\'=======\n",cmd);
                        printf("Processador Solicita configura'cao\n");
                        if (configModulo()>-1)
                        {
                            printf("--processador re-configurado!---\n");
                        }
                        valConfig = 0;
                    }
                }
                n++;
                printf(".%i.",n);
            }
        }
//  exit(0);

    }
    mysql_close(MySQL_con);
}
