void copiarString(char origem[], char destino[]) {
    for(int i=0; origem[i] != 0; ++i) {
        destino[i]=origem[i];
    }
}
int contarCaractere( char string[], char letra){
    int contador, tamanho, ocorrencia = 0, len=0;
    tamanho=strlen(string);
    for (contador=1;contador <= tamanho;contador++) {
        if(string[contador]==letra){
            ocorrencia++;
            len=contador;
        }
        return(len);
    }
}

int contaLen(char *s){

    int c=0;
    while (*(s+c))
        c++;

    return c;

}

char *pegaCmd (char *str){
    int tamanho = contaLen(str);
    char cmd[tamanho-2];
    int n;
    int c=0;
    for (n=0;n<tamanho;n++){
        if ((str[n]!='@') and (str[n]!=';')){
            cmd[c]=str[n];
            c++;
        }
    }
    return cmd;
}
int validaCMD (char *receba, char *st2){
    char *st1=pegaCmd(("%s",receba));
    printf ("cmd:%s\n",st1);
    while((*st1 == *st2) && (*st1)){
        st1++;
        st2++;
    }
    return ((*st1==NULL)&&(*st2==NULL));
}
char *substring(char *str, int inicio, int fim){
    char *saida;
    strncpy(saida,str+inicio,fim);
    return(saida);
}

void resetaModulo() {
    pinMode (RESET_ARDUINO,OUTPUT);
  //  printf("Resetando Modulo de controle.");
    digitalWrite(RESET_ARDUINO, HIGH);
    delay(500);
    digitalWrite(RESET_ARDUINO, LOW);
    delay(1500);
  //  printf(". OK.\n");
}
