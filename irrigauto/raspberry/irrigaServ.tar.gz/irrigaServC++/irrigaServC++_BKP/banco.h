int bd_sai_erro (MYSQL *con)
{
    fprintf(stderr,"%s\n",mysql_error(con));
    mysql_close(con);
    return -1;
}

int conectarBanco ()
{
    MySQL_con = mysql_init(NULL);
    printf("MySQL client version: %s\n", mysql_get_client_info());
    printf ("conectando banco... \n");
    int saida;
    if (mysql_real_connect (
                MySQL_con,      //  pointer to connection handler
                host,   //  host to connect to
                user,  	  //   user name
                pass,    //	   password
                db,  //   database to use
                0,             //  port (default 3306)
                NULL,         //   socket or /var/lib/mysql.sock
                0 )==NULL)         //    flags (none)
    {
        saida = bd_sai_erro (MySQL_con);
    } else {
        saida = 1;
    }
    return (saida);

//    mysql_query(conectar,"show databases");
//    res = mysql_store_result(conectar);
//    printf(res);
//    mysql_close ( conectar );
}
