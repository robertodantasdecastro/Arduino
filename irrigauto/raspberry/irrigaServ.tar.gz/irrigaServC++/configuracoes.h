int configuracoes (char cmd)
{
    char qry[1024];
    sprintf(qry, "SELECT fuso_horario,delay_verifica FROM configuracao WHERE id_modulo='%i';",ID_MODULO);

    if(mysql_query(MySQL_con, qry))
    {
        if (bd_sai_erro(MySQL_con) ==-1)
            return -1;
    }
    else
    {        MYSQL_RES *rs_delayAguarda=mysql_store_result(MySQL_con);

        if (rs_delayAguarda==NULL)
        {
            if (bd_sai_erro(MySQL_con) ==-1)
                return -1;
        }
        MYSQL_ROW linhaConfiguracao;
        int configNum=mysql_num_fields(rs_delayAguarda);
        while (linhaConfiguracao = mysql_fetch_row(rs_delayAguarda))
        {
            for(int i=0; i<configNum; i++)
            {
                if (i==0)
                {
                    int ret;
                    if (cmd == 'H'){
                        ret = atoi(linhaConfiguracao[0]);
                    }else
                    if (cmd == 'D'){ // comando D retora delay da verificacao em segundos
                        ret = atoi(linhaConfiguracao[1]);
                    }
                    return ret;
                }
            }
        }
    }
}
