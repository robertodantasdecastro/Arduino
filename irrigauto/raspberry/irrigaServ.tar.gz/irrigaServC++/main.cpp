#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <error.h>
#include <errno.h>
#include <termios.h>
#include <string.h>
#include <wiringPi.h>

#include <mysql/my_sys.h>
#include <mysql/my_global.h>
#include <mysql/mysql.h>

#include "config.h"
#include "funcoes.h"
#include "Serial.h"
#include "banco.h"
#include "configuracoes.h"
#include "configModulo.h"

int main(int argc, char **argv)
{
    printf ("--> iniciando...\n");
    bool verifica=true;
    if (wiringPiSetupSys() ==-1)
    {
        printf("WiringPi nao iniciou: %s\n", strerror(errno));
        return -1;
    } else
    if (conectarBanco())//conecta banco de dados
    {
        resetaModulo();
        int delayVerifica = configuracoes ('D');
        int configura = 0;
        bool verifica =true;
        while (verifica)
        {
            printf("---------LOOP--------\n");
            char *respCFG=lerSerial();
           // printf("recebendo serial: %s",respCFG);
           //int envia=enviarSerial("@teste;");
            if (validaCMD(respCFG,"CONFIG"))
            {
                resetaModulo();
                usleep(1000000);
                printf ("Executar rotina de configuracao!\n");
                int config = configModulo();
            }
            //int respostaSerial = verificaSerial(serialCon);
            usleep(1000000*delayVerifica);
        }
    }
}
